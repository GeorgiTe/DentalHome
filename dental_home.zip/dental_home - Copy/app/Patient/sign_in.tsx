import { Button, StyleSheet, Text, TextInput, TouchableOpacity, View, Image, Alert } from 'react-native';
import React, { useState } from 'react';
import { Link, useRouter } from 'expo-router';
import styles from '../../styles/styles';
import { SERVER_URL } from '@env';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function sign_in() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const router = useRouter();

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Грешка', 'Всички полета са задължителни');
      return;
    }

    try {
      console.log('Sending login request to:', `${SERVER_URL}/login`);
      const response = await fetch(`${SERVER_URL}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email,
          password: password,
        }),
      });

      const data = await response.json();
      console.log('Response:', data);

      if (response.status === 200) {
        await AsyncStorage.setItem('patientId', data.patient.id.toString());


        Alert.alert('Успех', 'Успешно влязохте в акаунта си');
        router.push('../Search/search');
      } else {
        Alert.alert('Грешка', data.error || 'Проблем при влизането');
      }
    } catch (error) {
      console.error('Error:', error);
      Alert.alert('Грешка', 'Проблем при влизането');
    }
  };

  return (
    <View style={styles.container}>
      <Image style={[styles.image, { bottom: 70 }]} source={require('../../assets/drive-download-20250129T091415Z-001/dentalhomeNOBG.png')} />
      <View style={styles.textContainer}>
        <Text style={styles.text}>Влезте в акаунта си</Text>
      </View>
      <View>
        <TextInput
          style={styles.input}
          placeholder="И-мейл"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
        />
        <TextInput
          style={styles.input}
          placeholder="Парола"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />
        <TouchableOpacity style={[styles.button, { marginTop: 25 }]} onPress={handleLogin}>
          <Text style={styles.buttonText}>Вход</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}