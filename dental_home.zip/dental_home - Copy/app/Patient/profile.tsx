import { Text, View, Alert, FlatList, TouchableOpacity, Image } from 'react-native';
import React, { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import styles from '../../styles/styles';
import { SERVER_URL } from '@env';

export default function Profile() {
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [patientInfo, setPatientInfo] = useState<{ name: string; email: string } | null>(null);

  useEffect(() => {
    const fetchPatientInfo = async () => {
      try {
        const patientId = await AsyncStorage.getItem('patientId');
        if (!patientId) {
          Alert.alert('Грешка', 'Не е намерен пациент ID.');
          return;
        }

        // Fetch patient details
        const response = await axios.get(`${SERVER_URL}/patients/${patientId}`);
        setPatientInfo(response.data);
      } catch (error) {
        console.error('Error fetching patient info:', error);
        Alert.alert('Грешка', 'Неуспешно зареждане на информацията за пациента.');
      }
    };

    const fetchAppointments = async () => {
      try {
        const patientId = await AsyncStorage.getItem('patientId');
        if (!patientId) {
          Alert.alert('Грешка', 'Не е намерен пациент ID.');
          return;
        }

        const response = await axios.get(`${SERVER_URL}/appointments/${patientId}`);
        setAppointments(response.data);
      } catch (error) {
        console.error('Error fetching appointments:', error);
        Alert.alert('Грешка', 'Неуспешно зареждане на часовете.');
      } finally {
        setLoading(false);
      }
    };

    fetchPatientInfo();
    fetchAppointments();
  }, []);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('bg-BG', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  const deleteAppointment = async (appointmentId: number) => {
    try {
      const response = await axios.delete(`${SERVER_URL}/appointments/${appointmentId}`);
      if (response.status === 200) {
        Alert.alert('Успех', 'Часът е изтрит успешно.');
        setAppointments((prevAppointments) =>
          prevAppointments.filter((appointment) => appointment.id !== appointmentId)
        );
      } else {
        Alert.alert('Грешка', 'Неуспешно изтриване на час.');
      }
    } catch (error) {
      console.error('Error deleting appointment:', error);
      Alert.alert('Грешка', 'Неуспешно изтриване на час.');
    }
  };

  const renderAppointment = ({ item }: { item: any }) => (
    <View style={styles.row}>
      <Text style={[styles.cell, { flex: 1.5 }]}>{formatDate(item.appointment_date)}</Text>
      <Text style={[styles.cell, { flex: 1.5 }]}>{item.treatment_type}</Text>
      <Text style={[styles.cell, { flex: 1 }]}>{item.city || 'Няма данни'}</Text>
      <Text style={[styles.cell, { flex: 1.5 }]}>{item.address || 'Няма данни'}</Text>
      <Text style={[styles.cell, { flex: 1.5 }]}>{item.dentist_name}</Text>
      <TouchableOpacity
        style={[styles.cell, { flex: 0.5, backgroundColor: '#DD4949', justifyContent: 'center', alignItems: 'center' }]}
        onPress={() => deleteAppointment(item.id)}
      >
        <Text style={{ color: '#000', fontWeight: 'bold' }}>Изтрий</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Patient Information */}
      {patientInfo && (
        <View style={styles.textContainer}>
          <Image style={[styles.image, { bottom: 70 }]} source={require('../../assets/drive-download-20250129T091415Z-001/dentalhomeNOBG.png')} />
          <Text style={styles.mainText}>Добре дошли, {patientInfo.name}</Text>
          <Text style={styles.mainText}>Имейл: {patientInfo.email}</Text>
        </View>
      )}

      <Text style={styles.mainText}>Моите часове</Text>
      {loading ? (
        <Text style={styles.text}>Зареждане...</Text>
      ) : appointments.length === 0 ? (
        <Text style={styles.text}>Нямате записани часове.</Text>
      ) : (
        <View style={styles.table}>
          {/* Table Header */}
          <View style={[styles.row, styles.header]}>
            <Text style={[styles.cell, { flex: 1.5 }]}>Дата</Text>
            <Text style={[styles.cell, { flex: 1.5 }]}>Лечение</Text>
            <Text style={[styles.cell, { flex: 1 }]}>Град</Text>
            <Text style={[styles.cell, { flex: 1.5 }]}>Адрес</Text>
            <Text style={[styles.cell, { flex: 1.5 }]}>Зъболекар</Text>
            <Text style={[styles.cell, { flex: 0.5 }]}>Действие</Text>
          </View>

          {/* Table Rows */}
          <FlatList
            data={appointments}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderAppointment}
            contentContainerStyle={{ paddingBottom: 20 }}
          />
        </View>
      )}
    </View>
  );
}