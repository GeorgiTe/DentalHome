import { Button, StyleSheet, Text, TextInput, TouchableOpacity, View, Image, KeyboardAvoidingView, Platform, TouchableWithoutFeedback, Keyboard, Alert, ActivityIndicator } from 'react-native';
import RNPickerSelect from 'react-native-picker-select';
import React, { useEffect, useState } from 'react';
import { useRouter } from 'expo-router';
import styles from '../../styles/styles';
import { SERVER_URL } from '@env';

export default function sign_up() {
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [repeatPassword, setRepeatPassword] = useState('');
  const [selectedCity, setSelectedCity] = useState<string | null>(null);
  const [cities, setCities] = useState<{ label: string; value: string }[]>([]);
  const [loading, setLoading] = useState(true);

  const router = useRouter();

  const PatientSignIn = () => {
    router.push('../Patient/sign_in');
  };

  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  };

  const validatePassword = (password: string) => {
    const re = /^(?=.*[a-zа-я])(?=.*[A-ZА-Я])(?=.*\d)[a-zA-Zа-яА-Я\d]{8,}$/;
    return re.test(password);
  };

  const handleSignUp = async () => {
    if (!validateEmail(email)) {
      Alert.alert('Грешка', 'Невалиден имейл адрес');
      return;
    }

    if (!validatePassword(password)) {
      Alert.alert('Грешка', 'Паролата трябва да съдържа поне 8 символа, включително главна буква, малка буква и цифра');
      return;
    }

    if (password !== repeatPassword) {
      Alert.alert('Греша+ка', 'Паролите не съвпадат');
      return;
    }

    if (!selectedCity) {
      Alert.alert('Грешка', 'Моля изберете град');
      return;
    }

    try {
      console.log('Sending registration request to:', `${SERVER_URL}/register`);
      const response = await fetch(`${SERVER_URL}/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: username,
          email: email,
          password: password,
          city: selectedCity,
        }),
      });

      const data = await response.json();
      console.log('Response:', data);

      if (response.status === 201) {
        Alert.alert('Успех', 'Регистрацията е успешна!');
        router.push('../Patient/sign_in');
      } else {
        Alert.alert('Грешка', '' + (data.error || 'Проблем при регистрацията'));
      }
    } catch (error) {
      console.error('Error:', error);
      Alert.alert('Грешка', 'Проблем при регистрацията');
    }
  };

  useEffect(() => {
    fetch(`${SERVER_URL}/cities`)
      .then((response) => response.json())
      .then((data: string[]) => {
        const formattedCities = data.map((city, index) => ({
          key: index.toString(),
          label: city,
          value: city,
        }));
        setCities(formattedCities);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching cities:', error);
        setLoading(false);
      });
  }, []);

  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.container}>
          <View style={styles.textContainer}>
            <Image style={[styles.image, { top: 35 }]} source={require('../../assets/drive-download-20250129T091415Z-001/dentalhomeNOBG.png')} />
          </View>
          <View style={styles.contentContainer}>
            <Text style={styles.text}>Въведете данните си</Text>
            <TextInput
              style={styles.input}
              placeholder="И-мейл"
              keyboardType="email-address"
              value={email}
              onChangeText={setEmail}
            />
            <TextInput
              style={styles.input}
              placeholder="Име и фамилия"
              value={username}
              onChangeText={setUsername}
            />
            {loading ? (
              <ActivityIndicator size="small" color="#0000ff" />
            ) : (
              <>
              <RNPickerSelect
                onValueChange={(value) => setSelectedCity(value)}
                items={cities}
                placeholder={{ label: 'Изберете град...', value: null }}
                style={{inputAndroid: styles.input }}
              />
              </>
            )}
            <TextInput
              style={styles.input}
              placeholder="Парола"
              secureTextEntry
              value={password}
              onChangeText={setPassword}
            />
            <TextInput
              style={styles.input}
              placeholder="Потвърдете паролата"
              secureTextEntry
              value={repeatPassword}
              onChangeText={setRepeatPassword}
            />
            
            <TouchableOpacity style={styles.button} onPress={handleSignUp}>
              <Text style={styles.buttonText}>Регистрация</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.textContainer, { top: 10 }]}>
            <Text style={[styles.text, { marginTop: 20 }]}>Вече имате акаунт?</Text>
            <TouchableOpacity style={[styles.button, { marginBottom: 60 }]} onPress={PatientSignIn}>
              <Text style={styles.buttonText}>Вход</Text>
            </TouchableOpacity>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}