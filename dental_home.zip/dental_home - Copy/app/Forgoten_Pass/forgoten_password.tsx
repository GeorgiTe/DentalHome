import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import styles from '../../styles/styles'

const forgoten_password = () => {
  return (
    <View style = {styles.container}>
      <Text>forgoten_password</Text>
    </View>
  )
}

export default forgoten_password

