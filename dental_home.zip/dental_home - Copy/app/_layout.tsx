import { Stack, usePathname } from 'expo-router'; // Import usePathname to get the current route
import React, { useEffect, useState } from 'react';
import { TouchableOpacity, View, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons'; // Import Ionicons for the house icon

export default function Layout() {
  const router = useRouter();
  const pathname = usePathname(); // Get the current route
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const patientId = await AsyncStorage.getItem('patientId');
        setIsLoggedIn(!!patientId); // Set to true if patientId exists
      } catch (error) {
        console.error('Error checking login status:', error);
      }
    };

    checkLoginStatus();
  }, [pathname]); // Re-run the effect when the route changes

  return (
    <Stack
      screenOptions={{
        headerStyle: {
          backgroundColor: '#005972',
          height: 100,
        },
        headerTintColor: '#000',
        headerTitleStyle: { fontWeight: 'bold' },
        headerTitleAlign: 'center',
        headerRight: () =>
          // Hide the icons on the login and registration pages
          pathname === '/Patient/sign_in' || pathname === '/Patient/sign_up' || pathname === '/' ? null : (
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              {/* Profile Icon */}
              {isLoggedIn ? (
                <TouchableOpacity
                  onPress={() => router.push('/Patient/profile')} // Navigate to the profile page
                  style={{ marginRight: 15 }}
                >
                  <View
                    style={{
                      width: 30,
                      height: 30,
                      borderRadius: 5,
                      backgroundColor: '#808080',
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <View
                      style={{
                        width: 15,
                        height: 15,
                        borderRadius: 7.5,
                        backgroundColor: '#fff',
                        marginBottom: 3,
                      }}
                    />
                    <View
                      style={{
                        width: 20,
                        height: 5,
                        backgroundColor: '#fff',
                        borderRadius: 2.5,
                      }}
                    />
                  </View>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  onPress={() => {
                    Alert.alert('Грешка', 'Моля, влезте в акаунта си, за да видите профила.');
                    router.push('/Patient/sign_in'); // Redirect to login page
                  }}
                  style={{ marginRight: 15 }}
                >
                  <View
                    style={{
                      width: 60,
                      height: 60,
                      borderRadius: 5,
                      backgroundColor: '#808080',
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <View
                      style={{
                        width: 25,
                        height: 25,
                        borderRadius: 12.5,
                        backgroundColor: '#fff',
                        marginBottom: 3,
                      }}
                    />
                    <View
                      style={{
                        width: 20,
                        height: 5,
                        backgroundColor: '#fff',
                        borderRadius: 2.5,
                      }}
                    />
                  </View>
                </TouchableOpacity>
              )}

              {/* House Icon for Search */}
              {isLoggedIn && (
                <TouchableOpacity
                  onPress={() => router.push('/Search/search')} // Navigate to the search page
                  style={{ marginRight: 15 }}
                >
                  <Ionicons name="home" size={30} color="#fff" />
                </TouchableOpacity>
              )}
            </View>
          ),
      }}
    >
      <Stack.Screen name="index" options={{ title: 'Dental Home' }} />
      <Stack.Screen name="Patient/sign_in" options={{ title: 'Вход' }} />
      <Stack.Screen name="Patient/sign_up" options={{ title: 'Регистрация' }} />
      <Stack.Screen name="Search/search" options={{ title: 'Търсене' }} />
      <Stack.Screen name="Search/dentist_profile" options={{ title: 'Профил' }} />
      <Stack.Screen name="Appointments/appointments" options={{ title: 'Запазете час' }} />
      <Stack.Screen name="Patient/profile" options={{ title: 'Моят профил' }} />
    </Stack>
  );
}