import {
  Text,
  TextInput,
  TouchableOpacity,
  View,
  FlatList,
  TouchableWithoutFeedback,
  Keyboard,
  Alert,
  Image,
  KeyboardAvoidingView,
} from 'react-native';
import React, { useState, useEffect } from 'react';
import RNPickerSelect from 'react-native-picker-select';
import { useRouter } from 'expo-router';
import styles from '../../styles/styles';
import { SERVER_URL } from '@env';

export default function search() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchType, setSearchType] = useState<'name' | 'city'>('name');
  const [cities, setCities] = useState<{ label: string; value: string }[]>([]);
  const [selectedCity, setSelectedCity] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [dentistSuggestions, setDentistSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedDentist, setSelectedDentist] = useState<string | null>(null);
  const [isManualSelection, setIsManualSelection] = useState(false);

  const router = useRouter();

  useEffect(() => {
    fetch(`${SERVER_URL}/cities`)
      .then((response) => response.json())
      .then((data: string[]) => {
        const formattedCities = data.map((city, index) => ({
          key: index.toString(),
          label: city,
          value: city,
        }));
        setCities(formattedCities);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching cities:', error);
        setLoading(false);
      });
  }, []);

  const handleSearch = () => {
    if (selectedDentist) {
      console.log(`Navigating to the profile of dentist: ${selectedDentist}`);
      router.push({
        pathname: '../Search/dentist_profile',
        params: { name: selectedDentist },
      });
      return;
    }

    if (searchType === 'name') {
      if (!searchQuery.trim()) {
        Alert.alert('Грешка', 'Моля въведете името на зъболекър.');
        return;
      }
      console.log('Searching for dentist by name:', searchQuery);
    } else if (searchType === 'city') {
      if (!selectedCity) {
        Alert.alert('Грешка', 'Моля изберете град за търсене.');
        return;
      }
      console.log('Searching for dentists in city:', selectedCity);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior="height">
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.container}>
          <Image
            style={styles.image}
            source={require('..//../assets/drive-download-20250129T091415Z-001/dentalhomeNOBG.png')}
          />
          <View style={styles.textContainer}>
            <Text style={styles.text}>Намерете вашият зъболекар тук</Text>
          </View>

          <View style={{ flexDirection: 'row', justifyContent: 'center', marginBottom: 20 }}>
            <TouchableOpacity
              style={[styles.toggleButton, searchType === 'name' && styles.activeToggleButton]}
              onPress={() => {
                setSearchType('name');
                setSearchQuery('');
                setSelectedDentist(null);
                setDentistSuggestions([]);
                setShowSuggestions(false);
              }}
            >
              <Text
                style={[
                  styles.toggleButtonText,
                  searchType === 'name' && styles.activeToggleButtonText,
                ]}
              >
                По име
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.toggleButton, searchType === 'city' && styles.activeToggleButton]}
              onPress={() => {
                setSearchType('city');
                setSearchQuery('');
                setSelectedDentist(null);
                setDentistSuggestions([]);
                setShowSuggestions(false);
              }}
            >
              <Text
                style={[
                  styles.toggleButtonText,
                  searchType === 'city' && styles.activeToggleButtonText,
                ]}
              >
                По град
              </Text>
            </TouchableOpacity>
          </View>

          {/* Input Field Based on Search Type */}
          {searchType === 'name' ? (
            <>
              <TextInput
                style={styles.input}
                placeholder="Въведете име на зъболекар"
                value={searchQuery}
                onChangeText={(text) => {
                  setSearchQuery(text);
                  setShowSuggestions(true);
                  if (text.trim() !== '') {
                    fetch(`${SERVER_URL}/search-dentists?name=${encodeURIComponent(text)}`)
                      .then((response) => response.json())
                      .then((data: string[]) => {
                        console.log('Fetched dentists by name:', data);
                        setDentistSuggestions(data);
                      })
                      .catch((error) => {
                        console.error('Error fetching dentist suggestions by name:', error);
                      });
                  } else {
                    setDentistSuggestions([]);
                  }
                }}
              />
              {showSuggestions && dentistSuggestions.length > 0 && (
                <FlatList
                  data={dentistSuggestions}
                  keyExtractor={(item, index) => index.toString()}
                  renderItem={({ item }) => (
                    <TouchableOpacity
                      onPress={() => {
                        setSearchQuery(item);
                        setSelectedDentist(item);
                        setShowSuggestions(false);
                        setIsManualSelection(true);
                      }}
                    >
                      <Text style={styles.suggestionItem}>{item}</Text>
                    </TouchableOpacity>
                  )}
                  style={[
                    styles.suggestionsList,
                    { maxHeight: Math.min(dentistSuggestions.length * 40, 200) },
                  ]}
                  keyboardShouldPersistTaps="handled"
                />
              )}
            </>
          ) : (
            <>
              <RNPickerSelect
                onValueChange={(value) => {
                  setSelectedCity(value);
                  setSearchQuery('');
                  if (value) {
                    fetch(`${SERVER_URL}/search-dentists?city=${encodeURIComponent(value)}`)
                      .then((response) => response.json())
                      .then((data: string[]) => {
                        console.log('Fetched dentists:', data);
                        setDentistSuggestions(data);
                        setShowSuggestions(true);

                        // Show alert if no dentists are found
                        if (data.length === 0) {
                          Alert.alert('Няма намерени зъболекари', 'Няма намерени зъболекари в този град.');
                        }
                      })
                      .catch((error) => {
                        console.error('Error fetching dentists for city:', error);
                      });
                  }
                }}
                items={cities}
                placeholder={{ label: 'Изберете град...', value: null }}
                style={{
                  inputAndroid: [styles.input],
                }}
              />
              {showSuggestions && dentistSuggestions.length > 0 && (
                <FlatList
                  data={dentistSuggestions}
                  keyExtractor={(item, index) => index.toString()}
                  renderItem={({ item }) => (
                    <TouchableOpacity
                      onPress={() => {
                        setSearchQuery(item);
                        setSelectedDentist(item);
                        setDentistSuggestions([item]);
                        setShowSuggestions(true);
                      }}
                    >
                      <Text style={styles.suggestionItem}>{item}</Text>
                    </TouchableOpacity>
                  )}
                  style={[
                    styles.suggestionsList,
                    { maxHeight: Math.min(dentistSuggestions.length * 40, 200) },
                  ]}
                  keyboardShouldPersistTaps="handled"
                />
              )}
            </>
          )}

          <TouchableOpacity style={styles.button} onPress={handleSearch}>
            <Text style={styles.buttonText}>Търсене</Text>
          </TouchableOpacity>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}