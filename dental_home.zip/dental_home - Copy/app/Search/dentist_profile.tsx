import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useLocalSearchParams, useRouter } from 'expo-router';
import styles from '../../styles/styles';
import { SERVER_URL } from '@env';

export default function DentistProfile() {
  const { name } = useLocalSearchParams(); // Use useLocalSearchParams to retrieve query parameters
  const router = useRouter(); // Use router for navigation
  const [profile, setProfile] = useState<{
    id: number; // Add the id property
    name: string;
    city: string | null;
    picture_url: string | null;
    address: string | null;
    email: string | null;
    phone: string | null;
  } | null>(null);

  useEffect(() => {
    const fetchDentistProfile = async () => {
      try {
        const response = await fetch(`${SERVER_URL}/get-dentist-profile?name=${encodeURIComponent(Array.isArray(name) ? name[0] : name)}`);
        const data = await response.json();
        console.log('Fetched profile data:', data); // Debugging
        if (data.error) {
          console.error('Error fetching dentist profile:', data.error);
        } else {
          setProfile(data); // Set the profile data
        }
      } catch (error) {
        console.error('Error fetching dentist profile:', error);
      }
    };

    fetchDentistProfile();
  }, [name]);

  return (
    <View style={styles.container}>
      {profile ? (
        <>
          {/* Dentist Name */}
          <Text style={styles.mainText}>{profile.name || 'Няма име'}</Text>

          {/* Dentist Picture */}
          {profile.picture_url ? (
            <Image
              source={{ uri: profile.picture_url }} // Use the picture_url directly
              style={styles.dentistImage}
            />
          ) : (
            <Text style={styles.text}>Няма налична снимка</Text>
          )}

          {/* Contact Details */}
          <View style={[styles.textContainer, { backgroundColor: '#808080', borderRadius: 10, padding: 10, maxWidth: '100%' }]}>
            <Text style={styles.mainText}>Контактна информация:</Text>
            {profile.city && <Text style={styles.text}>Град: {profile.city}</Text>}
            {profile.address && <Text style={styles.text}>Адрес: {profile.address}</Text>}
            {profile.email && <Text style={styles.text}>Имейл: {profile.email}</Text>}
            {profile.phone && <Text style={styles.text}>Телефон: {profile.phone}</Text>}
          </View>

          {/* Appointment Button */}
          <TouchableOpacity
            style={styles.button}
            onPress={() => {
              console.log('Navigating with params:', {
                dentistName: profile?.name,
                dentistId: profile?.id,
              });
              router.push({
                pathname: '../Appointments/appointments',
                params: {
                  dentistName: profile.name || 'Няма име',
                  dentistId: profile.id, // Pass the dentist ID
                  city: profile.city || 'Няма град',
                },
              });
            }}
          >
            <Text style={styles.buttonText}>Запази час</Text>
          </TouchableOpacity>
        </>
      ) : (
        <Text style={styles.text}>Зареждане...</Text>
      )}
    </View>
  );
}