import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Button, StyleSheet, Text, TouchableOpacity, View, Image } from 'react-native';
import * as Font from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import React, { useState, useEffect, useCallback } from 'react';
import styles from '../styles/styles';

SplashScreen.preventAutoHideAsync();

const fetchFonts = () => {
  return Font.loadAsync({
    'roboto-regular': require('../assets/fonts/Roboto-Regular.ttf'),
    'roboto-bold': require('../assets/fonts/Roboto-Bold.ttf'),
  });
};

export default function Index() {
  const [fontLoaded, setFontLoaded] = useState(false);
  const [isPressed, setIsPressed] = useState(false);

  useEffect(() => {
    async function loadResourcesAndDataAsync() {
      try {
        await fetchFonts();
      } catch (e) {
        console.warn(e);
      } finally {
        setFontLoaded(true);
        SplashScreen.hideAsync();
      }
    }

    loadResourcesAndDataAsync();
  }, []);

  const handlePressIn = () => {
    setIsPressed(true);
  };

  const handlePressOut = () => {
    setIsPressed(false);
  };

  const router = useRouter();
  const PatientSignUp = () => {
    router.push('/Patient/sign_up');
  };
  const PatientSignIn = () => {
    router.push('/Patient/sign_in');
  };

  
  return (
    <View style={styles.container}>
      <View style={styles.textContainer}>
        <Text style={[styles.mainText]}>Добре дошли в Dental Home</Text>
      </View>
      <View style={[styles.imageContainer]}>
        <Image style={styles.image} source={require('../assets/drive-download-20250129T091415Z-001/dentalhomeNOBG.png')} />
      </View>
      <View style={styles.contentContainer}>
        <View style={styles.buttonContainer}>
          <Text style={styles.text}>Нямате акаунт?</Text>
          <TouchableOpacity
            style={[styles.button, isPressed && styles.buttonPressed]}
            onPressIn={handlePressIn}
            onPressOut={handlePressOut}
            onPress={PatientSignUp}
          >
            <Text style={styles.buttonText}>Регистрация</Text>
          </TouchableOpacity>
          <Text style={styles.text}>Или влезте във вашия акаунт</Text>
          <TouchableOpacity
            style={[styles.button, isPressed && styles.buttonPressed]}
            onPressIn={handlePressIn}
            onPressOut={handlePressOut}
            onPress={PatientSignIn}
          >
            <Text style={styles.buttonText}>Вход</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}