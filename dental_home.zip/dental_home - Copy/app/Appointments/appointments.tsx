import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, Alert, TextInput, Image } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import axios from 'axios';
import styles from '../../styles/styles';
import { SERVER_URL } from '@env';
import { useLocalSearchParams, useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function Appointments() {
  const { dentistName, dentistId, city } = useLocalSearchParams();
  const router = useRouter();

  // Form state
  const [day, setDay] = useState<string>('');
  const [month, setMonth] = useState<string>('');
  const [year, setYear] = useState<string>(new Date().getFullYear().toString()); // Default to current year
  const [time, setTime] = useState<string | null>(null);
  const [treatmentType, setTreatmentType] = useState<string | null>(null);
  const [treatmentTypes, setTreatmentTypes] = useState<string[]>([]);
  const [patientId, setPatientId] = useState<number | null>(null);
  const [dentistPhoto, setDentistPhoto] = useState<string | null>(null);

  useEffect(() => {
    const fetchPatientId = async () => {
      try {
        const id = await AsyncStorage.getItem('patientId');
        if (id) {
          setPatientId(parseInt(id, 10));
        } else {
          Alert.alert('Грешка', 'Не е намерен пациент ID.');
        }
      } catch (error) {
        console.error('Error fetching patient ID:', error);
        Alert.alert('Error', 'Failed to retrieve patient information.');
      }
    };

    fetchPatientId();

    // Fetch treatment types from the backend
    const fetchTreatmentTypes = async () => {
      try {
        const response = await axios.get(`${SERVER_URL}/treatment-types`);
        setTreatmentTypes(response.data);
      } catch (error) {
        console.error('Error fetching treatment types:', error);
        Alert.alert('Error', 'Failed to load treatment types');
      }
    };

    fetchTreatmentTypes();

    // Fetch dentist photo
    const fetchDentistPhoto = async () => {
      try {
        const response = await axios.get(`${SERVER_URL}/get-dentist-profile?name=${encodeURIComponent(dentistName as string)}`);
        if (response.data && response.data.picture_url) {
          setDentistPhoto(response.data.picture_url);
        }
      } catch (error) {
        console.error('Error fetching dentist photo:', error);
      }
    };

    if (dentistName) {
      fetchDentistPhoto();
    }
  }, [dentistName]);

  const validateAppointment = () => {
    if (!day || !month || !year) {
      Alert.alert('Грешка', 'Моля, въведете валидна дата.');
      return false;
    }
  
    if (!time) {
      Alert.alert('Грешка', 'Моля, изберете време.');
      return false;
    }
  
    if (!treatmentType) {
      Alert.alert('Грешка', 'Моля, изберете вид лечение.');
      return false;
    }
  
    // Validate the year
    const currentYear = new Date().getFullYear();
    if (parseInt(year) !== currentYear) {
      Alert.alert('Грешка', `Можете да изберете само текущата година: ${currentYear}.`);
      return false;
    }
  
    // Validate the month
    const monthNumber = parseInt(month);
    if (isNaN(monthNumber) || monthNumber < 1 || monthNumber > 12) {
      Alert.alert('Грешка', 'Моля, въведете валиден месец (1-12).');
      return false;
    }
  
    // Validate the day based on the month and year
    const dayNumber = parseInt(day);
    if (isNaN(dayNumber) || dayNumber < 1 || dayNumber > getDaysInMonth(monthNumber, parseInt(year))) {
      Alert.alert('Грешка', `Моля, въведете валиден ден за избрания месец (${getDaysInMonth(monthNumber, parseInt(year))} дни).`);
      return false;
    }
  
    // Validate the date
    const appointmentDate = new Date(`${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${time}`);
    const currentDate = new Date();
  
    if (isNaN(appointmentDate.getTime())) {
      Alert.alert('Грешка', 'Моля, въведете валидна дата.');
      return false;
    }
  
    if (appointmentDate < currentDate) {
      Alert.alert('Грешка', 'Не можете да изберете дата, която вече е минала.');
      return false;
    }
  
    // Validate the time
    const [hour, minute] = time.split(':').map(Number);
    if (hour < 8 || hour > 17 || (hour === 17 && minute > 0)) {
      Alert.alert('Грешка', 'Моля, изберете час между 08:00 и 17:00.');
      return false;
    }
  
    return true;
  };
  
  // Helper function to get the number of days in a month
  const getDaysInMonth = (month: number, year: number): number => {
    return new Date(year, month, 0).getDate();
  };

  const createAppointment = async () => {
    if (!validateAppointment()) {
      return;
    }
  
    try {
      // Format the appointment date correctly
      const appointmentDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')} ${time}:00`;
  
      const response = await axios.post(`${SERVER_URL}/appointments`, {
        patient_id: patientId,
        dentist_id: dentistId,
        appointment_date: appointmentDate,
        treatment_type: treatmentType,
      });
  
      if (response.status === 201) {
        Alert.alert('Успех', 'Часът е записан успешно.');
        router.push('../Patient/profile');
      } else {
        Alert.alert('Грешка', response.data.error || 'Неуспешно записване на час.');
      }
    } catch (error) {
      console.error('Error creating appointment:', error);
      if ((error as any).response && (error as any).response.data && (error as any).response.data.error) {
        if (axios.isAxiosError(error) && error.response && error.response.data && error.response.data.error) {
          Alert.alert('Грешка', error.response.data.error); // Show backend error message
        } else {
          Alert.alert('Грешка', 'Неуспешно записване на час.');
        }
      } else {
        Alert.alert('Грешка', 'Неуспешно записване на час.');
      }
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.textContainer}>
        {/* Dentist Name */}
        <Text style={styles.text}>
          <Text style={styles.label}>Зъболекар:</Text> {dentistName || 'Unknown Dentist'}
        </Text>

        {/* Dentist Photo */}
        {dentistPhoto ? (
          <Image
            source={{ uri: dentistPhoto }}
            style={styles.dentistImage}
          />
        ) : (
          <Text style={styles.text}>Няма налична снимка</Text>
        )}

        {/* City */}
        <Text style={styles.text}>
          <Text style={styles.label}>Град:</Text> {city || 'Unknown City'}
        </Text>

        {/* Date Input */}
        <Text style={styles.label}>Изберете дата:</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
          <TextInput
            style={[styles.input, { flex: 1, marginRight: 5 }]}
            placeholder="Ден"
            keyboardType="numeric"
            value={day}
            onChangeText={setDay}
          />
          <TextInput
            style={[styles.input, { flex: 1, marginHorizontal: 5 }]}
            placeholder="Месец"
            keyboardType="numeric"
            value={month}
            onChangeText={setMonth}
          />
          <TextInput
            style={[styles.input, { flex: 1, marginLeft: 5 }]}
            placeholder="Година"
            keyboardType="numeric"
            value={year}
            editable={false} // Prevent user from editing the year
          />
        </View>

        {/* Time Picker */}
        <Text style={styles.label}>Изберете време:</Text>
        <Picker
          selectedValue={time}
          onValueChange={(itemValue: string | null) => setTime(itemValue)}
          style={styles.input}
        >
          <Picker.Item label="Изберете време" value={null} />
          {Array.from({ length: 18 }, (_, i) => {
            const hour = 8 + Math.floor(i / 2);
            const minute = i % 2 === 0 ? '00' : '30';
            return (
              <Picker.Item
                key={hour}
                label={`${hour.toString().padStart(2, '0')}:${minute}`}
                value={`${hour.toString().padStart(2, '0')}:${minute}`}
              />
            );
          })}
        </Picker>

        {/* Treatment Type Picker */}
        <Text style={styles.label}>Изберете лечение </Text>
        <Picker
          selectedValue={treatmentType}
          onValueChange={(itemValue: string | null) => setTreatmentType(itemValue)}
          style={styles.input}
        >
          <Picker.Item label="Видове прегледи" value={null} />
          {treatmentTypes.map((type, index) => (
            <Picker.Item key={index} label={type} value={type} />
          ))}
        </Picker>

        {/* Create Appointment Button */}
        <TouchableOpacity style={styles.button} onPress={createAppointment}>
          <Text style={styles.buttonText}>Запиши</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}