create database dh;
use dh;
CREATE TABLE patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    city varchar(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dentists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    city_id int not null,
    address VARCHAR(255) NOT NULL,
    phone VARCHAR(20) UNIQUE,  
    email VARCHAR(100) UNIQUE, 
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (city_id) REFERENCES cities(id)
);

CREATE TABLE appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    dentist_id INT NOT NULL,
    appointment_date DATETIME NOT NULL,
    city_id int not null,
    treatment_type ENUM(
        'Почистване на зъбен камък',  
        'Пломбиране на кариес',      
        'Изваждане на зъб',         
        'Консултация за брекети',    
        'Избелване',                 
        'Преглед'                    
    ) NOT NULL, 
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (dentist_id) REFERENCES dentists(id) ON DELETE CASCADE,
    FOREIGN KEY (city_id) REFERENCES cities(id)
);


INSERT INTO dentists (name, city, city_id, address, phone, email) VALUES
('Д-р Симеон Златанов', 'София', 1, 'ул. Витоша 15', '+359 88 123 4567', 'simeon.zlatanov@example.com'),
('Д-р Теодора Костадинова', 'Пловдив', 2, 'бул. България 22', '+359 88 987 6543', 'teodora.kostadinova@example.com'),
('Д-р Борислав Великов', 'Варна', 3, 'ул. Черно море 10', '+359 88 456 7890', 'borislav.velikov@example.com'),
('Д-р Емилия Трифонова', 'Бургас', 4, 'ул. Лазур 5', '+359 88 321 6547', 'emilia.trifonova@example.com'),
('Д-р Христина Радева', 'Русе', 5, 'ул. Дунав 18', '+359 88 654 3210', 'hristina.radeva@example.com');

ALTER TABLE dentists ADD COLUMN picture_url VARCHAR(255) DEFAULT NULL;

CREATE TABLE cities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
);
