require("dotenv").config({path:'../backend/.env'});
const express = require("express");
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const cors = require("cors");
const jwt = require("jsonwebtoken");
console.log("JWT_SECRET:", process.env.JWT_SECRET);
const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json()); 

const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

db.connect(err => {
    if (err) {
        console.error("Database connection failed:", err);
    } else {
        console.log("Connected to MySQL database");
    }
});

app.post("/register", async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: "All fields are required" });

    const hashedPassword = await bcrypt.hash(password, 10);

    const sql = "INSERT INTO patients (name, email, password) VALUES (?, ?, ?)";
    db.query(sql, [name, email, hashedPassword], (err, result) => {
        if (err) return res.status(500).json({ error: "Database error" });
        res.status(201).json({ message: "Patient registered successfully", id: result.insertId });
    });
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: "All fields are required" });

  const sql = "SELECT * FROM patients WHERE email = ?";
  db.query(sql, [email], async (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (results.length === 0) return res.status(404).json({ error: "Patient not found" });

    const patient = results[0];
    const isMatch = await bcrypt.compare(password, patient.password);
    if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });

    // Generate a token (e.g., JWT) with the patient's ID
    const token = jwt.sign({ id: patient.id }, process.env.JWT_SECRET, { expiresIn: "1h" });

    res.status(200).json({
      message: "Login successful",
      token,
      patient: { id: patient.id, name: patient.name, email: patient.email },
    });
  });
});

app.get("/patients", (req, res) => {
    const sql = "SELECT id, name, email, created_at FROM patients";
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: "Database error" });
        res.json(results);
    });
});

app.get("/patients/:id", (req, res) => {
    const sql = "SELECT id, name, email, created_at FROM patients WHERE id = ?";
    db.query(sql, [req.params.id], (err, result) => {
        if (err) return res.status(500).json({ error: "Database error" });
        if (result.length === 0) return res.status(404).json({ error: "Не е намерен пациент" });
        res.json(result[0]);
    });
});

app.delete("/patients/:id", (req, res) => {
    const sql = "DELETE FROM patients WHERE id = ?";
    db.query(sql, [req.params.id], (err, result) => {
        if (err) return res.status(500).json({ error: "Database error" });
        res.json({ message: "Patient deleted successfully" });
    });
});

app.get("/cities", async (req, res) => {
  try {
    // Fetch all cities from the `cities` table and sort them alphabetically
    const [rows] = await db.promise().query("SELECT name FROM cities ORDER BY name ASC");

    // Map the rows to return only the city names
    const cities = rows.map((row) => row.name);

    res.json(cities); // Return the sorted list of cities
  } catch (error) {
    console.error("Error fetching cities:", error);
    res.status(500).json({ error: "Database error" });
  }
});

  app.get('/search-dentists', async (req, res) => {
    const { name, city } = req.query;
  
    // Validate input
    if (!name && !city) {
      return res.status(400).json({ error: 'Either name or city is required' });
    }
  
    try {
      let query = 'SELECT name FROM dentists WHERE 1=1';
      const params = [];
  
      // Add name filter if provided
      if (name) {
        query += ' AND name LIKE ?';
        params.push(`%${name}%`);
      }
  
      // Add city filter if provided
      if (city) {
        query += ' AND city = ?';
        params.push(city);
      }
  
      query += ' LIMIT 10'; // Limit the results to 10
  
      const [rows] = await db.promise().query(query, params);
      res.json(rows.map(row => row.name));
    } catch (error) {
      console.error('Error searching dentists:', error);
      res.status(500).json({ error: 'Database error' });
    }
  });

  const multer = require('multer');
const path = require('path');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Save files in the 'uploads' folder
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`); // Generate a unique filename
  },
});

const upload = multer({ storage });

app.put('/update-dentist-picture', async (req, res) => {
  const { dentistId, picture_url } = req.body;

  if (!dentistId || !picture_url) {
    return res.status(400).json({ error: 'Dentist ID and picture URL are required' });
  }

  try {
    const [result] = await db.promise().query(
      'UPDATE dentists SET picture_url = ? WHERE id = ?',
      [picture_url, dentistId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Dentist not found' });
    }

    res.json({ message: 'Picture URL updated successfully' });
  } catch (error) {
    console.error('Error updating dentist picture:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

app.get('/get-dentist-profile', async (req, res) => {
  const { name } = req.query;
  if (!name) {
    return res.status(400).json({ error: 'Name is required' });
  }

  try {
    const [rows] = await db.promise().query(
      'SELECT id, name, picture_url, address, email, phone, city FROM dentists WHERE name = ?',
      [name]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Dentist not found' });
    }
    console.log('Fetched dentist profile:', rows[0]); // Debugging
    res.json(rows[0]); // Return the dentist's profile data
  } catch (error) {
    console.error('Error fetching dentist profile:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// Create a new appointment
app.post('/appointments', async (req, res) => {
  const { patient_id, dentist_id, appointment_date, treatment_type } = req.body;

  if (!patient_id || !dentist_id || !appointment_date || !treatment_type) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    // Validate patient_id
    const [patientRows] = await db.promise().query('SELECT id FROM patients WHERE id = ?', [patient_id]);
    if (patientRows.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    // Validate dentist_id and fetch city_id
    const [dentistRows] = await db.promise().query('SELECT id, city_id FROM dentists WHERE id = ?', [dentist_id]);
    if (dentistRows.length === 0) {
      return res.status(404).json({ error: 'Dentist not found' });
    }
    const city_id = dentistRows[0].city_id;

    // Check if the time slot is already booked
    const [appointmentRows] = await db.promise().query(
      'SELECT id FROM appointments WHERE dentist_id = ? AND appointment_date = ?',
      [dentist_id, appointment_date]
    );
    if (appointmentRows.length > 0) {
      return res.status(400).json({ error: 'This time slot is already booked for the dentist.' });
    }

    // Insert the appointment with the city_id
    const sql = `
      INSERT INTO appointments (patient_id, dentist_id, appointment_date, treatment_type, city_id)
      VALUES (?, ?, ?, ?, ?)
    `;
    const [result] = await db.promise().query(sql, [
      patient_id,
      dentist_id,
      appointment_date,
      treatment_type,
      city_id,
    ]);
    res.status(201).json({ message: 'Appointment created successfully', id: result.insertId });
  } catch (error) {
    console.error('Error creating appointment:', error);
    res.status(500).json({ error: 'Database error' });
  }
});


app.get('/treatment-types', async (req, res) => {
  try {
    const [rows] = await db.promise().query(`
      SELECT COLUMN_TYPE 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_NAME = 'appointments' AND COLUMN_NAME = 'treatment_type'
    `);

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Treatment types not found' });
    }

    // Extract ENUM values from the COLUMN_TYPE field
    const enumValues = rows[0].COLUMN_TYPE.match(/'([^']+)'/g).map((value) => value.replace(/'/g, ''));
    res.json(enumValues);
  } catch (error) {
    console.error('Error fetching treatment types:', error);
    res.status(500).json({ error: 'Database error' });
  }
});
// Get all appointments for a patient
app.get('/appointments/:patient_id', async (req, res) => {
  const { patient_id } = req.params;

  try {
    const sql = `
      SELECT 
        a.id, 
        a.appointment_date, 
        a.treatment_type, 
        d.name AS dentist_name, 
        d.city, 
        d.address
      FROM appointments a
      JOIN dentists d ON a.dentist_id = d.id
      WHERE a.patient_id = ?
      ORDER BY a.appointment_date ASC
    `;
    const [rows] = await db.promise().query(sql, [patient_id]);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching appointments:', error);
    res.status(500).json({ error: 'Database error' });
  }
});
// Delete an appointment
app.delete('/appointments/:id', async (req, res) => {
  const { id } = req.params;

  try {
      const sql = 'DELETE FROM appointments WHERE id = ?';
      const [result] = await db.promise().query(sql, [id]);

      if (result.affectedRows === 0) {
          return res.status(404).json({ error: 'Appointment not found' });
      }

      res.json({ message: 'Appointment deleted successfully' });
  } catch (error) {
      console.error('Error deleting appointment:', error);
      res.status(500).json({ error: 'Database error' });
  }
});

app.get('/appointments/:dentist_id', async (req, res) => {
  const { dentist_id } = req.params;

  try {
    const sql = `
      SELECT a.id, a.appointment_date, a.treatment_type, d.name AS dentist_name
      FROM appointments a
      JOIN dentists d ON a.dentist_id = d.id
      WHERE a.dentist_id = ?
      ORDER BY a.appointment_date ASC
    `;
    const [rows] = await db.promise().query(sql, [dentist_id]);

    if (rows.length === 0) {
      console.log(`No appointments found for dentist_id: ${dentist_id}`);
      return res.json([]);
    }

    res.json(rows);
  } catch (error) {
    console.error('Error fetching appointments:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// Delete a dentist by ID
app.delete('/dentists/:id', async (req, res) => {
  const { id } = req.params;

  try {
    // Check if the dentist exists
    const [dentistRows] = await db.promise().query('SELECT id FROM dentists WHERE id = ?', [id]);
    if (dentistRows.length === 0) {
      return res.status(404).json({ error: 'Dentist not found' });
    }

    // Delete the dentist
    const sql = 'DELETE FROM dentists WHERE id = ?';
    const [result] = await db.promise().query(sql, [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Dentist not found' });
    }

    res.json({ message: 'Dentist deleted successfully' });
  } catch (error) {
    console.error('Error deleting dentist:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});